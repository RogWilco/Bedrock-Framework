<?php
namespace Bedrock\Common\Registry;

/**
 * Registry Exception
 *
 * @package Bedrock
 * @author Nick Williams
 * @version 1.1.0
 * @created 03/10/2009
 * @updated 07/02/2012
 */
class Exception extends \Bedrock\Common\Exception {}