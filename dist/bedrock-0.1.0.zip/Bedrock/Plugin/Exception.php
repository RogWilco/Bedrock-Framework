<?php
namespace Bedrock\Plugin;

/**
 * A general exception thrown by plugins.
 *
 * @package Bedrock
 * @author Nick Williams
 * @version 1.1.0
 * @created 06/07/2009
 * @updated 07/02/2012
 */
class Exception extends \Bedrock\Common\Exception {}